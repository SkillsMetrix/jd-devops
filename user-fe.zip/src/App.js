import { useState, useEffect } from "react";

function App() {

  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");

  const loadMessages = async () => {

    const res = await fetch(
      "http://localhost:8000/messages"
    );

    const data = await res.json();

    setMessages(data);
  };

  useEffect(() => {
    loadMessages();
  }, []);

  const submit = async () => {

    await fetch(
      "http://localhost:8000/messages",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ text })
      }
    );

    setText("");

    loadMessages();
  };

  return (
    <div style={{ padding: 30 }}>
      <h1> Wonder Board</h1>

      <input
        value={text}
        onChange={(e) => setText(e.target.value)}
      />

      <button onClick={submit}>
        Save
      </button>

      <ul>
        {
          messages.map((msg) => (
            <li key={msg.id}>
              {msg.message}
            </li>
          ))
        }
      </ul>
    </div>
  );
}

export default App;